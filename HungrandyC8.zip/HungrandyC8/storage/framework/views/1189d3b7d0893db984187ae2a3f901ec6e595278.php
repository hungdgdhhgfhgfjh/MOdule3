
<?php $__env->startSection("header"); ?>

<div class="container">
<h1 class="text-primary">thêm người dùng</h1>
    <div class="row">
        <div class="col-4">
            <form action="<?php echo e(route('admin.store')); ?>" method="POST" >
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="exampleInputEmail1">tên người</label>
                    <input type="text" class="form-control"  name="name">
                    <div style="width: 316px;" ><b  class="alert-danger"><?php echo e($errors->first('name')); ?></b></div>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">email</label>
                    <input type="email" name="email" class="form-control" >
                    <div style="width: 316px;" ><b  class="alert-danger"><?php echo e($errors->first('email')); ?></b></div>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">password</label>
                    <input type="password" name="password" class="form-control" >
                    <div style="width: 316px;" ><b  class="alert-danger"><?php echo e($errors->first('password')); ?></b></div>
                </div>
                <button type="submit" class="btn btn-primary">thêm</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("staffs.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\HungrandyC8\resources\views/users/create.blade.php ENDPATH**/ ?>