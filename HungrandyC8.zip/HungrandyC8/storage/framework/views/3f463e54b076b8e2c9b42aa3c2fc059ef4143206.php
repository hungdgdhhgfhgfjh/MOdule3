
<?php $__env->startSection("header"); ?>

<h1 class="text-center text-primary">Đăng Nhập</h1>
<div id="content" style="height: 250px;" >
<div class="container" style="background-color:white; border-radius:10px;">
<div class="col-4">
<form action="<?php echo e(route('admin.handlelogin')); ?>" method="post">
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="email">Email:</label>
    <input value="<?php echo e(old('email')); ?>" name="email" type="email" style="width: 316px;" class="form-control" placeholder="Enter email" >
    <div class="col-12">
            <?php if(Session::has('error_email')): ?>
            <p style="width:360px" class="alert-danger">
                <i class="fa fa-check" aria-hidden="true"></i><?php echo e(Session::get('error_email')); ?>

            </p>
            <?php endif; ?>
        </div>
  </div>
  <div class="form-group">
    <label for="pwd">Mật khẩu:</label>
    <input value="<?php echo e(old('password')); ?>" name="password" type="password" style="width: 316px;" class="form-control" placeholder="Enter password">
    <div class="col-12">
            <?php if(Session::has('error_password')): ?>
            <p style="width:250px" class="alert-danger">
                <i class="fa fa-check" aria-hidden="true"></i><?php echo e(Session::get('error_password')); ?>

            </p>
            <?php endif; ?>
        </div>
  </div>
 
  <button type="submit" style="width: 316px;" class="btn btn-primary">Đăng Nhập</button>
</form> 
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("staffs.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\HungrandyC8\resources\views/login.blade.php ENDPATH**/ ?>