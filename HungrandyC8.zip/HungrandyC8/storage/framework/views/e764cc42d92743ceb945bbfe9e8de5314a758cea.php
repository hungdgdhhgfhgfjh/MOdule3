
<?php $__env->startSection("header"); ?>

<div class="container">
<h1 class="text-primary">thêm nhân viên</h1>
    <div class="row">
        <div class="col-4">
            <form action="<?php echo e(route('staffs.update',$staff->id)); ?>" method="POST" >
            <?php echo csrf_field(); ?>
            <?php echo method_field("put"); ?>
                <div class="form-group">
                    <label for="exampleInputEmail1">tên nhân viên</label>
                    <input type="text" value="<?php echo e($staff->Full_name); ?>"class="form-control"  name="Full_name">
                    <div style="width: 316px;" ><b  class="alert-danger"><?php echo e($errors->first('Full_name')); ?></b></div>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Nhóm nhân viên</label>
                    <input type="text" value="<?php echo e($staff->Staff_group); ?>" name="Staff_group" class="form-control" >
                    <div style="width: 316px;" ><b  class="alert-danger"><?php echo e($errors->first('Staff_group')); ?></b></div>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Giới tính</label>
                    <input type="text" value="<?php echo e($staff->Sex); ?>"   name="Sex" class="form-control" >
                    <div style="width: 316px;" ><b  class="alert-danger"><?php echo e($errors->first('Sex')); ?></b></div>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">số điện thoại</label>
                    <input type="text"  value="<?php echo e($staff->Phone_number); ?>" name="Phone_number" class="form-control" >
                    <div style="width: 316px;" ><b  class="alert-danger"><?php echo e($errors->first('Phone_number')); ?></b></div>
                </div>
                <button type="submit" class="btn btn-primary">thay đổi</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("staffs.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\HungrandyC8\resources\views/staffs/edit.blade.php ENDPATH**/ ?>