
<?php $__env->startSection("header"); ?>
<h1 class="text-primary text-center" >người dùng</h1>
<div class="col-12">
            <?php if(Session::has('success')): ?>
            <p style="width:200px" class="alert-success">
            <i class="fas fa-check"></i><?php echo e(Session::get('success')); ?>

            </p>
            <?php endif; ?>
        </div>
        <nav class="navbar navbar-light bg-light">
  <form class="form-inline">
    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
  </form>
</nav>
<a class="btn btn-primary ml-4" href="<?php echo e(route('admin.create')); ?>">thêm người dùng</a>
<a class="btn btn-primary ml-4" href="<?php echo e(route('admin.login')); ?>">đăng nhập</a>
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Mã người dùng</th>
      <th scope="col">email</th>
      <th scope="col">họ tên</th>
   
    </tr>
  </thead>
  <tbody>
  <?php if(count($users)===0): ?>
  <tr>
    <td colspan="7">chưa có nhân viên</td>
    </tr>
    <?php else: ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td scope="col"><?php echo e($user->id); ?></td>
      <td scope="col"><?php echo e($user->name); ?></td>
      <td scope="col"><?php echo e($user->email); ?></td>
     <td></td>
      <td></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("staffs.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\HungrandyC8\resources\views/users/index.blade.php ENDPATH**/ ?>