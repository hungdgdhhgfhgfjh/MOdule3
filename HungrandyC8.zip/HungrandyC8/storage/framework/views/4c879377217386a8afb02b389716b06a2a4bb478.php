
<?php $__env->startSection("header"); ?>
<h1 class="text-primary text-center" >Nhân viên</h1>
<div class="col-12">
            <?php if(Session::has('success')): ?>
            <p style="width:200px" class="alert-success">
            <i class="fas fa-check"></i><?php echo e(Session::get('success')); ?>

            </p>
            <?php endif; ?>
        </div>
        <nav class="navbar navbar-light bg-light">
  <form class="form-inline" action="#" method="get">
    <input name="search" class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
  </form>
</nav>
<a class="btn btn-primary ml-4" href="<?php echo e(route('staffs.create')); ?>">thêm nhân viên</a>
<a   class="btn btn-primary ml-4" href="<?php echo e(route('admin.logout')); ?>">đăng xuất</a>
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Mã nhân viên</th>
      <th scope="col">Nhóm nhân viên</th>
      <th scope="col">Họ tên</th>
      <th scope="col">Giới tính</th>
      <th scope="col">Số điện thoại</th>
      <th scope="col">thay đổi</th>
      <th scope="col">xóa</th>
    </tr>
  </thead>
  <tbody>
  <?php if(count($staffs)===0): ?>
  <tr>
    <td colspan="7">chưa có nhân viên</td>
    </tr>
    <?php else: ?>
    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td scope="col"><?php echo e($staff->id); ?></td>
      <td scope="col"><?php echo e($staff->Staff_group); ?></td>
      <td scope="col"><?php echo e($staff->Full_name); ?></td>
      <td scope="col"><?php echo e($staff->Sex); ?></td>
      <td scope="col"><?php echo e($staff->Phone_number); ?></td>
      <td scope="col"><a class="btn btn-primary" href="<?php echo e(route('staffs.edit',$staff->id)); ?>">thay đổi</a> </td>
      <form action="<?php echo e(route('staffs.destroy',$staff->id)); ?>" method="POST" >
      <?php echo csrf_field(); ?>
      <?php echo method_field("delete"); ?>
      <td scope="col"><button onclick="return confirm('bạn có muốn xóa không')" class="btn btn-danger" >xóa</button> </td>
      </form>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("staffs.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\HungrandyC8\resources\views/staffs/index.blade.php ENDPATH**/ ?>