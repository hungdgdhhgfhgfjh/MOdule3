
<?php $__env->startSection("header"); ?>

<div class="container">
<h1 class="text-primary">thêm nhân viên</h1>
    <div class="row">
        <div class="col-4">
            <form action="<?php echo e(route('staffs.store')); ?>" method="POST" >
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="exampleInputEmail1">tên nhân viên</label>
                    <input type="text" class="form-control"  name="Full_name">
                    <div style="width: 316px;" ><b  class="alert-danger"><?php echo e($errors->first('Full_name')); ?></b></div>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Nhóm nhân viên</label>
                    <input type="text" name="Staff_group" class="form-control" >
                    <div style="width: 316px;" ><b  class="alert-danger"><?php echo e($errors->first('Staff_group')); ?></b></div>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Giới tính</label>
                    <input type="text" name="Sex" class="form-control" >
                    <div style="width: 316px;" ><b  class="alert-danger"><?php echo e($errors->first('Sex')); ?></b></div>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">số điện thoại</label>
                    <input type="text" name="Phone_number" class="form-control" >
                    <div style="width: 316px;" ><b  class="alert-danger"><?php echo e($errors->first('Phone_number')); ?></b></div>
                </div>
                <button type="submit" class="btn btn-primary">thêm</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("staffs.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\HungrandyC8\resources\views/staffs/create.blade.php ENDPATH**/ ?>